from __future__ import absolute_import

from .the_best_colors import __doc__, print_maps, get_map, _get_all_maps

globals().update(_get_all_maps())
