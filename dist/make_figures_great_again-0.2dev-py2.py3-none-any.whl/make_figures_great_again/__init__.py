"""
Make Plots Great Again.
"""
from . import the_best_colors

version = __version__ = '0.1dev'

print 'WARNING: Could not find "platform" module. "platform" does not exist!'
