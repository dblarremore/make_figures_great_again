Make Figures Great Again

Thanks to `palettable <https://jiffyclub.github.io/palettable/>`_, upon whose shoulders we stand, hoping to make plots great again.